import json

def phonebook():
    adressbook= {}
    last = 'Last name'
    first = 'First name'
    name = input('Input you name: ')
    surname = input('Input you surname: ')
    adressbook[last,first] = name,surname
    adressbook['city'] = input('Input you city: ')
    adressbook['number'] = input('Input you number: ')
    return [{k,v} for k,v in adressbook ]

phonebook()