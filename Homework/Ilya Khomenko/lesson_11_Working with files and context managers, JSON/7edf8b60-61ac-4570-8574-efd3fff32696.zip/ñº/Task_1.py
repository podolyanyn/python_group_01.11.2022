x = 'Hello file world!'

with open('myfile.txt','w') as fw:
    fw.write(x)


with open('myfile.txt','r') as fr:
    print(fr.readline())