import json
import sys

menu = """Phone Book
========================
1. Add contact
2. Display by first name
3. Display by city
4. Distpay by second name
5. Display by number
6. Display by full name 
7. Delete a contact
8. Update all entries
9. Quit 
========================
"""



class PhoneBook():
  def __init__(self,first_name,second_name,city,number) -> None:
    self.first_name = first_name
    self.second_name = second_name
    self.city = city
    self.number = number
    self.phonebook = {}


  def load():
    global name,db
    name = input('Enter a name of json file: ')
    try:
      with open(f'{name}', 'r') as file:
          db = json.load(file)
          print('Database successfully loaded. Chose option to continue')
          PhoneBook.start()
    except FileNotFoundError:  # (7)
      if input('Phonebook not found. Any key to create new or [E] to exit: ').lower() == 'e':
          sys.exit("Sometimes it's better stop before you get too far. Goodbye!")
      else:
          print('Phonebook is empty')

  def start():
        print(menu)
        user_input = input("What do you want to do (select 1-9)? ")
        if user_input == "1":
            return PhoneBook.user_input1()
        if user_input == "2":
            return PhoneBook.user_input2()
        if user_input == "3":
            return PhoneBook.user_input3()
        if user_input == "4":
            return PhoneBook.user_input4()
        if user_input == "5":
            return PhoneBook.user_input5()
        if user_input == "6":
            return PhoneBook.user_input6()
        if user_input == "7":
            return PhoneBook.user_input7()
        if user_input == "8":
            return PhoneBook.user_input8()
        if user_input == "9":
            return PhoneBook.user_input9()

  def add(self):
    self.phonebook['Name'] = self.first_name
    self.phonebook['Surname'] = self.second_name
    self.phonebook['City'] = self.city
    self.phonebook['Number'] = self.number
    db.append(self.phonebook)
    with open(f'{name}', 'w') as file:
        json.dump(db, file, indent=4)
    print("%s has been added to the phone book." % self.first_name)
    return self.phonebook

  def search_by_name():
      for entry in db:
        if srch in entry['Name']:
          print(entry)
      PhoneBook.start()

  def search_by_city():
    for entry in db:
      if srch in entry['City']:
        print(entry)
    PhoneBook.start()

  def search_by_last_name():
    for entry in db:
      if srch in entry['Surname']:
        print(entry)
    PhoneBook.start()

  def search_by_number():
    for entry in db:
      if srch in entry['Number']:
        print(entry)
        PhoneBook.start()
  
  def search_by_full_name():
    for entry in db:
      if srch in entry['Name'] and srch_1 in entry['Surname'] :
        print(entry)
        PhoneBook.start()

  def delete():
    for entry in db:
      if search_number in entry['Number']:
        db.pop(db.index(entry))
        with open(f'{name}', 'w') as file:
          json.dump(db, file, indent=4)
        print('Contact deleted')
    PhoneBook.start()

  def update(self):
    for entry in db:
      if search_number in entry['Number']:
        entry['Name'] = self.first_name
        entry['Surname'] = self.second_name
        entry['City'] = self.city
        entry['Number'] = self.number
        db[(db.index(entry))] = entry
        with open(f'{name}', 'w') as file:
          json.dump(db, file, indent=4)
        print('Update')
    PhoneBook.start()


  def user_input1():
    first_name = input("What is the contact's first name? ")
    second_name = input("What is the contact's second name? ")
    city = input("Enter a city: ")
    phone_num = input("What is the contact's phone number ")
    first_name = PhoneBook(first_name,second_name,city,phone_num)
    first_name.add()
    PhoneBook.start()

  def user_input2():
    global srch
    srch = input('Enter a name: ')
    PhoneBook.search_by_name()
    


  def user_input3():
    global srch
    srch = input('Enter a city: ')
    PhoneBook.search_by_city()

  def user_input4():
    global srch
    srch = input('Enter a last name: ')
    PhoneBook.search_by_last_name()


  def user_input5():
      global srch
      srch = input('Enter a number: ')
      PhoneBook.search_by_number()

  def user_input6():
    global srch,srch_1
    srch = input('Enter a name: ')
    srch_1 = input('Enter a last name: ')
    PhoneBook.search_by_full_name()

  def user_input7():
    global search_number
    search_number = input('Enter a number: ')
    PhoneBook.delete()
    

  def user_input8():
    global search_number
    search_number = input('Enter a number: ')
    first_name = input("What is the contact's first name? ")
    second_name = input("What is the contact's second name? ")
    city = input("Enter a city: ")
    phone_num = input("What is the contact's phone number ")
    first_name = PhoneBook(first_name,second_name,city,phone_num)
    first_name.update()
    PhoneBook.start()


  def user_input9():
    sys.exit()



PhoneBook.load()



