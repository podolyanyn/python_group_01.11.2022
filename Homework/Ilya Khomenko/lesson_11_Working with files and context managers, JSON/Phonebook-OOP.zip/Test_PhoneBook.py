import unittest
import json
class Test(unittest.TestCase):
    def test_load(self):
        with open('phonebook.json', 'r') as f:
            text = f.readlines()
            expect_out = ['[\n', '    {\n', '        "Name": "Polina",\n', '        "Surname": "Isacova",\n', '        "City": "Kiev",\n', '        "Number": "0971867838"\n', '    },\n', '    {\n', '        "Name": "Oksana",\n', '        "Surname": "Homneko",\n', '        "City": "Kiev",\n', '        "Number": "0963455167"\n', '    },\n', '    {\n', '        "Name": "Illja",\n', '        "Surname": "Homenko",\n', '        "City": "Kiev",\n', '        "Number": "0970039685"\n', '    }\n', ']']
            self.maxDiff = None
        self.assertEqual(text,expect_out)

    def test_invalid_load(self):
         inp_u =  input('Enter a name of json file: ')
         self.assertEqual(inp_u,'phonebook.json')

    def test_add(self):
        phonebook = {}
        db = []
        phonebook['Name'] = input('Enter a name: ')
        phonebook['Surname'] = input('Enter a surname: ')
        phonebook['City'] = input('Enter a city: ')
        phonebook['Number'] = input('Enter a number: ')
        db.append(phonebook)
        with open('phonebook1.json', 'w') as file:
            json.dump(db, file, indent=4)
        
        self.assertEqual(db[0],phonebook)
        return phonebook

    def test_field_null(self):
        phonebook = {}
        db = []
        phonebook['Name'] = input('Enter a name: ')
        phonebook['Surname'] = input('Enter a surname: ')
        phonebook['City'] = input('Enter a city: ')
        phonebook['Number'] = input('Enter a number: ')
        db.append(phonebook)
        with open('phonebook1.json', 'w') as file:
            json.dump(db, file, indent=4)
            x = db[0]
            for i in x.values():
                self.assertNotEqual(i,'')
        return phonebook

   
unittest.main()




