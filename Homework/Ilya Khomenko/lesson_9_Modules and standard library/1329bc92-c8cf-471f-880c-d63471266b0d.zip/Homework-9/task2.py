from task1 import summary


def summary_square():
    x = summary(10,5)

    return x**2

print(summary_square())