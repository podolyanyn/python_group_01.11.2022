def summary(a,b):
    return a+b

summary(10,5)