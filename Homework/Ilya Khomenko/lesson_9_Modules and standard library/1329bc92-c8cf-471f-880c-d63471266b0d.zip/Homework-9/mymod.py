def count_lines(name):
    with open(name) as f:
        x = len(f.readlines())
        print(x)
print(count_lines('C:\\Users\\illja\\OneDrive\\Desktop\\git\\Homework-9-10\\exsample.txt'))


def count_chars(name):
    with open(name) as f:
        y = len(f.read().replace(" ",""))
        
        print(y)

print(count_chars('C:\\Users\\illja\\OneDrive\\Desktop\\git\\Homework-9-10\\exsample.txt'))


def test(file_name):
    count_lines(file_name)
    count_chars(file_name)
print(test('exsample.txt'))